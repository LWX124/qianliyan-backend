create definer = root@`%` event e_refresh_accident_realness_view on schedule
    every '1' DAY
        starts '2018-08-29 01:00:00'
    on completion preserve
    enable
    do
    CALL refresh_biz_accident_realness_view ();

