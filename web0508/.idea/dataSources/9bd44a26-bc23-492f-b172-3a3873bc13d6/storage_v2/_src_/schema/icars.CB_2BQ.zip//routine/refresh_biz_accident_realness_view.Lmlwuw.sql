create
    definer = root@`%` procedure refresh_biz_accident_realness_view()
BEGIN
	TRUNCATE TABLE biz_accident_realness_view;
	INSERT INTO biz_accident_realness_view ( openid, total, exist, notexist ) SELECT
	openid AS openid,
	count( 1 ) AS total,
	count( IF ( ( realness = 0 ), TRUE, NULL ) ) AS exist,
	count( IF ( ( realness = 1 ), TRUE, NULL ) ) AS notexist 
	FROM
		biz_accident 
	GROUP BY
		openid;
END;

