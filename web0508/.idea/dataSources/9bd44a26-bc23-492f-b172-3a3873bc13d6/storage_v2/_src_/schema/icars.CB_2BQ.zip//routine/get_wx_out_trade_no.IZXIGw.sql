create
    definer = root@`%` function get_wx_out_trade_no() returns varchar(20)
BEGIN
    DECLARE getval VARCHAR(24); 
    SET getval = (SELECT CONCAT(DATE_FORMAT(NOW(), '%Y%m%d%H%i%s'),  LPAD((SELECT next_wx_out_trade_no('out_trade_no')), 6, '0')));
    RETURN getval;
END;

