create
    definer = root@`%` function get_maintain_order_num() returns varchar(20)
BEGIN
    DECLARE getval VARCHAR(24); 
    SET getval = (SELECT CONCAT(DATE_FORMAT(NOW(), '%Y%m%d%H%i%s'),  LPAD((SELECT next_open_claim_order_num('maintain_order')), 6, '0')));
    RETURN getval;
END;

