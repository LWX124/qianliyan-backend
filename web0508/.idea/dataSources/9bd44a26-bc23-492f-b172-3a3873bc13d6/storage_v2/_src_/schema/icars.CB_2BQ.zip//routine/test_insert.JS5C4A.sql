create
    definer = root@`%` procedure test_insert()
BEGIN 
DECLARE y INT DEFAULT 1;
WHILE y<100000
DO
INSERT INTO `icars`.`biz_accident`(`openid`, `video`, `lng`, `lat`, `checkId`, `status`, `address`, `createTime`, `checkTime`, `version`) VALUES ( 'om2cE5sWR9AN028nm5Rg3LlKOOy0', 'https://chejiqiche.com/video/ntocVXdJtNAHQoFu.mp4', 104.0647600000, 30.5702000000, 'admin', 2, '四川省成都市武侯区新世纪环球购物中心', '2018-08-14 15:57:21', '2018-08-14 15:57:40', NULL);

SET y=y+1; 
END WHILE ; 
commit; 
END;

