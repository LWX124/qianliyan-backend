create
    definer = root@`%` function next_wx_out_trade_no(seq_name varchar(30)) returns varchar(100)
BEGIN
    UPDATE sequence SET value=IF(last_insert_id(value+next)>= 999998,0,last_insert_id(value+next)) WHERE name=seq_name; 
    RETURN last_insert_id();
END;

